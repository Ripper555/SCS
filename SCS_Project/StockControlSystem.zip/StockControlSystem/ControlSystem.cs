﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockControlSystem
{
    public class ControlSystem
    {
        private List<Item> _itemList;
        private List<Supplier> _supplierList;
        private List<Order> _orderList;
        private List<Transaction> _transactionList;

        public ControlSystem()
        {
            _itemList = new List<Item>();
            _supplierList = new List<Supplier>();
            _orderList = new List<Order>();
            _transactionList = new List<Transaction>();
        }

        public Item locateItem(int bC)
        {
            return _itemList.Find(i => i.getBarCode() == bC);
        }

        public Item locateItemKey(int k)
        {
            return _itemList.Find(i => i.getKey() == k);
        }

        public void addSupplier(Supplier s)
        {
            _supplierList.Add(s);
        }

        public void addItem(Item i)
        {
            _itemList.Add(i);
        }

        public void addTransaction(Transaction t)
        {
            _transactionList.Add(t);
        }

        public void clearTransaction()
        {
            _transactionList.Clear();
        }

        public string[] listSuppliers()
        {
            string[] s = new string[_supplierList.Count()];
            int i = 0;
            foreach (Supplier sp in _supplierList)
            {
                s[i] = sp.ToString();
                i++;
            }
            return s;
        }

        public string[] listStock()
        {
            string[] s = new string[_itemList.Count()];
            int i = 0;
            foreach (Item it in _itemList)
            {
                s[i] = it.ToString();
                i++;
            }
            return s;
        }

        public string[] listScarceStock()
        {
            List<string> s = new List<string>();
            foreach (Item it in _itemList)
            {
                if (it.checkScarce()) s.Add(it.ToString());
            }
            return s.ToArray();
        }

        public void addOrder(string date, int q, int k)
        {
            _orderList.Add(new Order(date, q, locateItemKey(k)));
        }

        public Order locateOrder(int k)
        {
            return _orderList.Find(o => o.getKey() == k);
        }

        public Supplier locateSupplier(int k)
        {
            return _supplierList.Find(s => s.key == k);
        }

        public void removeOrder(int key)
        {
            Order temp = locateOrder(key);
            temp.executeOrder();
            _orderList.Remove(temp);
        }

        public double totalTransactions()
        {
            double total = 0;
            foreach (Transaction t in _transactionList)
            {
                t.totalTransaction();
                total += t.getTotal();
            }

            return total;
        }

        public string[] listTransactions()
        {
            List<string> sl = new List<string>();
            foreach (Transaction t in _transactionList)
            {
                sl.AddRange(t.displayItems());
            }

            sl.Add("========================================");
            sl.Add("Total for the Day = " + String.Format("{0:0.00}", totalTransactions()));

            return sl.ToArray();
        }

        public string[] listOrders()
        {
            List<string> sl = new List<string>();
            foreach (Order o in _orderList)
            {
                sl.Add(o.ToString());
            }

            return sl.ToArray();
        }

        public void removeTransactions()
        {
            _transactionList.Clear();
        }
        
    }
}
