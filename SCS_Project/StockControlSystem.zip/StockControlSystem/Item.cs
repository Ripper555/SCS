﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockControlSystem
{
    public class Item
    {
        
        private string _itemName;
        private int _stockQuantity;
        private int _orderThreshold;
        private double _retailPrice;
        private bool _isScarce;
        private Supplier _preferredSupplier;
        private int _key;
        private int _barCode;

        public Item(int bc, string iN, int sq, int ot, double rp, int k, Supplier ps)
        {
            _barCode = bc;
            _itemName = iN;
            _stockQuantity = sq;
            _orderThreshold = ot;
            _retailPrice = rp;
            _key = k;

            _preferredSupplier = ps;

            stockCheck();
        }

        public bool compBarCode(int b) {
            if (_barCode == b) return true;

            return false;
        }

        public void addStock(int q)
        {
            _stockQuantity += q;
            stockCheck();
        }

        public void removeStock(int q)
        {
            _stockQuantity -= q;
            stockCheck();
        }

        public bool checkScarce()
        {
            return _isScarce;
        }

        public void stockCheck()
        {
            if (_stockQuantity <= _orderThreshold) _isScarce = true;
            else _isScarce = false;
        }

        public string listTransaction()
        {
            return _itemName + ": " + String.Format("{0:0.00}", _retailPrice);
        }

        public string getName()
        {
            return _itemName;
        }

        public double getPrice()
        {
            return _retailPrice;
        }

        public int getBarCode()
        {
            return _barCode;
        }

        public int getKey()
        {
            return _key;
        }

        public Supplier getSupplier()
        {
            return _preferredSupplier;
        }

        public override string ToString()
        {
            return "{" + _key + "}" + _itemName + ", " + _barCode + ", " + _retailPrice + ", " 
                + _orderThreshold + ", " + _stockQuantity + "[" + _preferredSupplier.ToString() + "]";
        }
    }
}
