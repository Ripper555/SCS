﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockControlSystem
{
    public class Order
    {
        private int _itemKey;
        private string _datePlaced;
        private int _quantity;
        private Item _orderItem;

        public Order(string dp, int q, Item oi)
        {
            _datePlaced = dp;
            _quantity = q;
            _orderItem = oi;
            _itemKey = _orderItem.getKey();
        }

        public int getKey()
        {
            return _itemKey;
        }

        public void executeOrder()
        {
            _orderItem.addStock(_quantity);
        }

        public override string ToString()
        {
            return _datePlaced + " [" + _quantity + "]:  " + _orderItem.ToString();
        }
    }
}
