﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockControlSystem
{
    public class Supplier
    {
        private string _phoneNumber;
        private string _name;
        private string _address;
        public int key { get; set; }

        public Supplier(string pn, string n, string a, int k)
        {
            _phoneNumber = pn;
            _name = n;
            _address = a;
            key = k;
        }

        public bool checkKey(int k)
        {
            if (key == k) return true;

            return false;
        }

        public override string ToString()
        {
            return key + ": " + _name + ", " + _address + ", " + _phoneNumber;
        }

    }
}
