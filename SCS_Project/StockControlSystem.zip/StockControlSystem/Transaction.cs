﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StockControlSystem
{
    public class Transaction
    {
        private double _total;
        private List<TransactionItem> _transactionItemList;

        public Transaction() 
        {
            _transactionItemList = new List<TransactionItem>();
        }

        public void addItem(Item i)
        {
            TransactionItem ti = checkItem(i.getBarCode());
            if (ti == null) _transactionItemList.Add(new TransactionItem(i));
            else ti.incrementQuantity();
        }

        public TransactionItem checkItem(int barCode)
        {
            return _transactionItemList.Find(ti => ti.getBarCode() == barCode);
        }

        public void totalTransaction()
        {
            _total = 0;
            foreach (TransactionItem ti in _transactionItemList)
            {
                _total += ti.getPrice();
            }
        }

        public void executeTransaction()
        {
            foreach (TransactionItem ti in _transactionItemList)
            {
                ti.executeTransaction();
            }
            totalTransaction();
        }

        public double getTotal()
        {
            return _total;
        }

        public List<string> displayItems()
        {
            List<string> sl = new List<string>();
            
            foreach (TransactionItem ti in _transactionItemList)
            {
                sl.Add(ti.ToString());
            }

            sl.Add("-------------------------------------");
            sl.Add("\t\tTotal = " + String.Format("{0:0.00}", _total));

            return sl;
        }
    }
}
