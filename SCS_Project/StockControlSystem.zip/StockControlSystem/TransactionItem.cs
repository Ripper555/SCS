﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockControlSystem
{
    public class TransactionItem
    {
        private int _quantity;
        private Item _transactionItem;
        private int _barCode;

        public TransactionItem(Item ti)
        {
            _quantity = 1;
            _transactionItem = ti;
            _barCode = _transactionItem.getBarCode();
        }

        public void incrementQuantity()
        {
            _quantity++;
        }

        public double getPrice()
        {
            return _transactionItem.getPrice() * _quantity;
        }

        public int getBarCode()
        {
            return _barCode;
        }

        public void executeTransaction()
        {
            _transactionItem.removeStock(_quantity);
        }

        public override string ToString()
        {
            return _transactionItem.listTransaction() + " --- " + _quantity;
        }
    }
}
